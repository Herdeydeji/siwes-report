PRODUCT REQUIREMENTS DOCUMENT
SIWES Studio
Version 1.0 — Initial Product Definition
1. Product Overview
Working product name: SIWES Studio
Product category: Academic document preparation SaaS
Target market: Students in Nigerian universities, polytechnics and colleges of education undertaking the Students Industrial Work Experience Scheme (SIWES).
Primary purpose:
SIWES Studio is a web-based platform that helps students transform their actual industrial training records, logbooks, academic information and institutional report guidelines into comprehensive, professionally formatted SIWES reports.
The application will use document intelligence and AI-assisted writing to organise source information, generate structured academic content, review the report and export it into editable Microsoft Word and PDF formats.
The platform must prioritise factual accuracy, institution-specific formatting and user control.
2. Problem Statement
Students undertaking SIWES frequently experience difficulties with:


Converting daily logbook entries into formal academic writing.

Organising several weeks or months of industrial activities.

Understanding how to structure the five report chapters.

Obtaining their institution's correct report format.

Preparing preliminary pages, tables of contents, references and appendices.

Formatting Word documents properly.

Producing professional DOCX and PDF versions.
Generic AI writing tools do not necessarily understand the student's actual logbook, the distinction between performed and observed activities, or the specific formatting requirements of individual institutions.
SIWES Studio will address these problems through an integrated report preparation workflow.
3. Target Users
Primary users
Nigerian university, polytechnic and college of education students who have completed or are undertaking SIWES.
Secondary users


Students who need to organise their industrial training records.

SIWES coordinators and departmental administrators.

Institutions interested in providing approved report templates.
Main user characteristics


Frequently access the internet through Android smartphones.

May have limited internet bandwidth.

May upload handwritten or photographed logbook pages.

May not understand advanced document formatting.

Prefer straightforward instructions and guided workflows.

Expect transparent pricing in Nigerian naira.
4. Product Goals


Reduce the difficulty of preparing SIWES reports.

Produce accurate reports based on students' actual training activities.

Support different institutional report formats.

Provide a simple workflow for inexperienced computer users.

Generate editable DOCX and print-ready PDF documents.

Monetise through free access, individual purchases and optional premium plans.

Build a scalable institutional-template library for Nigerian tertiary institutions.
5. Core Product Modules
5.1 User Authentication


Email and password registration.

Google sign-in.

Email verification.

Password recovery.

Secure session management.

User profile management.
5.2 Student Onboarding
Collect:


Full name.

Matriculation or registration number.

Institution.

Faculty or school.

Department.

Programme and qualification.

Academic session.

SIWES commencement date.

SIWES completion date.

Host organisation.

Department or unit of placement.

Organisation address.
Support institution searching and institution-specific templates.
Allow students to save incomplete onboarding information and continue later.
5.3 Document Upload and Intelligence
Support:


PDF logbooks.

DOCX logbooks.

JPG and PNG photographs of logbook pages.

PDF institutional guidelines.

DOCX institutional guidelines.

University or polytechnic logo images.
The system must:


Extract text and relevant information from uploaded documents.

Process scanned and photographed pages where possible.

Identify weekly activities and dates.

Identify the student's equipment, tools and software exposure.

Detect missing, unclear or conflicting entries.

Identify the distinction between activities performed, assisted with and observed.

Maintain a link between extracted information and the original source.
Show extraction progress and understandable error messages.
5.4 Logbook Review System
Before generating the report, present extracted logbook information for student verification.
Features:


Weekly activity cards.

Individual date and activity entries.

Edit extracted text.

Add missing information manually.

Delete incorrect extracted entries.

Mark activity as performed, assisted or observed.

Flag missing dates.

Highlight uncertain extraction.

Confirm reviewed activities.
Do not generate unsupported activities to fill gaps.
5.5 Institutional Template Manager
Each supported institution should have a configurable report template.
Template configuration should include:


Institution name.

Logo.

Faculty and department.

Report title and cover-page structure.

Required preliminary pages.

Chapter structure.

Heading hierarchy.

Font family and size.

Line spacing.

Margins.

Page-numbering conventions.

Table and figure formatting.

Reference requirements.

Appendix requirements.
Students should be able to upload their departmental guidelines when a verified institutional template is unavailable.
An uploaded guideline must be analysed and converted into editable formatting requirements. The extracted rules should be shown to the student for confirmation.
Do not assume all institutions use the same report structure.
5.6 AI Report Generation Engine
Generate a complete SIWES report using:


Student academic information.

Verified logbook entries.

Host organisation information.

Institutional template.

Student-confirmed supplementary information.
Expected report sections:
Preliminary pages


Cover page.

Certification.

Dedication.

Acknowledgements.

Abstract.

Table of contents.

List of tables.

List of figures.
Chapter One: Introduction


Background of SIWES.

Objectives of SIWES.

Importance of SIWES.

Scope of training.

Organisation of the report.
Chapter Two: Host Organisation


Organisation background and history.

Objectives and functions.

Organisational structure.

Organogram, when verified.

Placement department.

Departmental functions.

Safety precautions.
Chapter Three: Work Experience


Introduction.

Orientation and familiarisation.

Technical activities performed.

Weekly industrial training account.

Equipment and systems encountered.

Relevant technical procedures.
Chapter Four: Experience Gained


Technical knowledge acquired.

Practical skills developed.

Equipment and tools used.

Software encountered.

Workplace experience.

Relationship between classroom learning and practical work.
Chapter Five: Challenges and Conclusion


Problems encountered.

How challenges were addressed.

Recommendations to the host organisation.

Recommendations to the institution.

Recommendations to future SIWES students.

Conclusion.
These are initial default sections. Institutional templates must be able to modify them.
5.7 Academic Accuracy and Verification
This is a major product differentiator.
The system must never:


Invent activities.

Invent company history.

Fabricate staff members or organisational structures.

Claim an observed task was independently performed.

Invent technical specifications.

Invent references or citations.

Silently resolve contradictions in source documents.
Every generated weekly activity should be traceable to the student's uploaded logbook or verified supplementary information.
Provide an activity-source inspection feature.
5.8 Report Editor
Provide a report editing workspace with:


Chapter navigation.

Editable report sections.

Automatic saving.

Report preview.

Page layout preview.

Section regeneration.

Manual text corrections.

Formatting controls.

Report completion indicators.
The student must retain control over the final report.
5.9 Document Export
Generate:


Microsoft Word (.docx).

PDF (.pdf).
DOCX should remain editable.
PDF should be suitable for printing and submission.
Support:


Correct page numbering.

Table of contents.

Page breaks.

Consistent headings.

Tables and figures.

Institutional formatting rules.
Both files must contain the same approved report content.
5.10 Student Dashboard
Dashboard elements:


Welcome section.

Create new SIWES report.

Existing report projects.

Report completion progress.

Recent activity.

Saved drafts.

Available credits or plan.

Payment history.

Help and support.
5.11 Payment and Monetisation
Use Bachs.io for payment processing.
All prices should be configurable by the administrator and displayed in NGN.
Free plan


Account creation.

One active project.

Upload logbook and institutional guidelines.

Preview extracted activities.

Review extracted information.

Preview proposed report structure.

Limited report preview.
Single Report Purchase


Full report generation.

Access to the report editor.

DOCX export.

PDF export.

A defined allowance for regeneration and revisions.
Premium Plan


Multiple report projects.

Higher report-generation allowance.

Additional revision allowances.

Access to supported institutional templates.

Priority processing where available.

Extended project storage, subject to stated limits.
Do not choose final prices in code. Create an admin-controlled pricing system.
Free users must understand exactly what is included before paying.
5.12 Payment Workflow


Student selects a paid package.

Backend creates a pending order.

Backend creates a Bachs checkout session.

Student is redirected to Bachs checkout.

Bachs sends a payment webhook to the application.

Backend verifies the webhook signature.

Transaction status and order ownership are checked.

Paid entitlement is activated.

Student can access the purchased report features.
The payment success redirect must never be treated as proof of payment.
Implement webhook idempotency and secure transaction records.
5.13 Admin Dashboard
Administrators should be able to:


View registered users.

View report projects.

Manage supported institutions.

Create and update institutional templates.

Manage university logos.

Review uploaded template guidelines.

Manage pricing and subscription plans.

View transactions.

Inspect failed payments.

Manage generation limits.

View application usage statistics.

Disable accounts when necessary.

Manage support requests.
Use role-based access control.
6. Proposed Technology Architecture
Frontend


React.

TypeScript.

Responsive design.

Component-based UI.

Mobile-first layout.
Backend


Node.js server-side runtime.

Secure API routes.

Server-only API credentials.

Validation and error handling.
Authentication and Database


Firebase Authentication.

Cloud Firestore.

Firebase Admin SDK for trusted server-side operations.
File Storage


Firebase Storage or Google Cloud Storage.

Private user folders.

Ownership checks.

Secure download access.
AI and Document Processing


Gemini API through server-side calls.

PDF and DOCX text extraction.

Image and scanned-document processing.

Structured JSON extraction.

Source-grounded report generation.
Payments


Bachs.io.

Official Node.js SDK where appropriate.

Webhook verification.

Server-side order management.
Document Generation


DOCX generation library.

PDF rendering solution.

Shared canonical report data model.

Automated document validation.
Hosting


Google Cloud Run or another supported production deployment target.
7. Security and Privacy


Keep Gemini and Bachs secret keys on the backend.

Never expose private API keys in browser code.

Apply Firebase security rules.

Restrict files to their owners.

Validate uploaded file types and sizes.

Restrict administrative functions.

Validate all server-side operations.

Protect payment webhooks.

Prevent duplicate payment fulfilment.

Allow users to delete their projects and uploaded documents.

Clearly disclose document retention rules.

Do not use private student documents for training without explicit consent.
8. Performance and Accessibility


Responsive desktop, tablet and mobile layouts.

Mobile-first interface.

Good performance on low-end Android devices.

Compressed previews where appropriate.

Upload progress indicators.

Save drafts automatically.

Handle weak network connections.

Allow recovery from interrupted upload or generation operations.

Use readable fonts and accessible colour contrast.

Keep the workflow simple for first-time users.
9. Initial MVP Scope
The first production release must concentrate on:


Authentication.

Student onboarding.

UNIOSUN as the first complete reference template.

Generic configurable institution templates.

Logbook uploads.

Guideline uploads.

Document extraction.

Extracted-information review.

SIWES report generation.

Report editing and preview.

DOCX and PDF exports.

Free and paid access.

Bachs payment integration.

Basic admin dashboard.
Do not build unrelated academic project generators, plagiarism-checking services, job placement systems or social networking features in the MVP.
10. Success Criteria
The MVP should be considered successful when:


A student can register and create a project.

A student can upload a supported logbook.

The application extracts and presents actual logbook entries.

The student can correct extracted information.

The application applies a selected institutional template.

The report generator creates all required chapters.

The student can edit the generated report.

DOCX and PDF exports open correctly.

Paid access is only unlocked after server-verified payment.

User documents remain private.

The application works properly on mobile and desktop.
11. Product Principles


Accuracy before impressive-looking AI output.

Student control before automated decisions.

Institution-specific formatting over generic report templates.

Transparent pricing.

Mobile-first accessibility.

Reliable exports.

Secure document handling.

Modular architecture for future expansion.