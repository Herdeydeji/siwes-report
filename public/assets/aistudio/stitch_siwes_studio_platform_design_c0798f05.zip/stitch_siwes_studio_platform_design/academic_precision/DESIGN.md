---
name: Academic Precision
colors:
  surface: '#f9f9ff'
  surface-dim: '#d4daeb'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e8eeff'
  surface-container-high: '#e2e8f9'
  surface-container-highest: '#dde2f3'
  on-surface: '#161c28'
  on-surface-variant: '#594238'
  inverse-surface: '#2a303d'
  inverse-on-surface: '#ecf0ff'
  outline: '#8c7166'
  outline-variant: '#e0c0b2'
  surface-tint: '#a23f00'
  primary: '#a23f00'
  on-primary: '#ffffff'
  primary-container: '#f36b21'
  on-primary-container: '#521c00'
  inverse-primary: '#ffb595'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e4e2e1'
  on-secondary-container: '#656464'
  tertiary: '#4d44e3'
  on-tertiary: '#ffffff'
  tertiary-container: '#8986ff'
  on-tertiary-container: '#1b009b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb595'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7c2e00'
  secondary-fixed: '#e4e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#f9f9ff'
  on-background: '#161c28'
  surface-variant: '#dde2f3'
  canvas-bg: '#F7F8FA'
  surface-card: '#FFFFFF'
  border-subtle: '#E6E8EC'
  heading-primary: '#202124'
  text-muted: '#8C93A3'
  status-performed: '#10B981'
  status-performed-subtle: '#ECFDF5'
  status-assisted: '#F59E0B'
  status-assisted-subtle: '#FFFBEB'
  status-observed: '#3B82F6'
  status-observed-subtle: '#EFF6FF'
  status-error: '#EF4444'
  status-error-subtle: '#FEF2F2'
typography:
  display-hero:
    fontFamily: Poppins
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Poppins
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Poppins
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Poppins
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Poppins
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Poppins
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-badge:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-dense:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system embodies an authoritative, academic-grade SaaS platform built specifically for Nigerian university and polytechnic students preparing high-stakes SIWES industrial training reports. It avoids generic consumer AI gimmicks, ephemeral gradients, or outdated governmental web portal tropes. Instead, it projects the focused restraint of an enterprise-grade document engineering studio: credible, distraction-free, structured, and profoundly transparent.

The design movement is **Modern Academic Utility**—a hybrid of systematic minimalism and institutional clarity. The interface treats student logbooks and generated text with archival respect. Visual weight is concentrated on document veracity, verification states (distinguishing performed, assisted, and observed tasks), and structural compliance with Nigerian tertiary institution formats. Because many users access the studio via entry-level to mid-range Android devices under bandwidth-constrained conditions, the visual language prioritizes crisp rendering, zero decorative layout overhead, immediate legibility, and large, physical-grade touch surfaces (minimum 44px).

## Colors

The palette establishes immediate functional hierarchy through high-contrast structural anchors, a focused energy accent, and dedicated verification status cues.

- **Primary Warm Orange (`#F36B21`)**: Reserved strictly for high-priority interactive touchpoints, primary export and generation calls-to-action, active stage indicators, and verified progress milestones. It avoids decorative overuse to preserve visual urgency.
- **Dark Charcoal (`#242424`)**: Acts as the structural backbone for top navigation bars, key institutional metadata banners, and primary CTA hover states, lending weight and institutional authority.
- **Tertiary Slate Blue (`#4F46E5`) / System Accent (`#3B82F6`)**: Applied to document structure references, source-linking cues, and "Observed" activity badges.
- **Canvas & Surface Architecture**: `#F7F8FA` forms a light, clean, paper-adjacent background, while `#FFFFFF` defines interactive cards and document preview sheets. The border `#E6E8EC` provides crisp boundary separation without visual noise.
- **Semantic Academic Verification Tokens**:
  - `status-performed` (`#10B981` with `#ECFDF5` background): Tasks completed directly by the student.
  - `status-assisted` (`#F59E0B` with `#FFFBEB` background): Tasks carried out under supervision or co-executed.
  - `status-observed` (`#3B82F6` with `#EFF6FF` background): Passive shadowing, inspection, or attendance.
  - `status-error` (`#EF4444` with `#FEF2F2` background): Missing dates, upload OCR failures, or compliance errors.

## Typography

The typographic hierarchy implements a functional dual-engine model:

1. **Poppins (Headers & Shell Navigation)**: Provides crisp, modern, confident geometric letterforms for dashboard milestones, chapter headings, and key workspace titles. Its controlled structure lends an approachable yet authoritative tone that appeals to university students and faculty coordinators.
2. **Inter (Dense Metadata, Editor Surface & Reports)**: Forms the high-density workhorse across multi-week logbook logs, form elements, table data, and live document previews. Inter guarantees legibility under small optical sizes on low-density mobile viewports.
3. **JetBrains Mono**: Used selectively for extraction confidence scores, metadata IDs, page anchors, and source traceability tags.

Headlines larger than 24px automatically reduce by one tier on mobile screens to preserve line-wrapping discipline when displaying lengthy Nigerian university titles, faculties, and matriculation identifiers.

## Layout & Spacing

The platform uses a fluid-responsive 12-column grid on desktop displays (collapsing to 6 columns on tablet and a single continuous vertical stack on mobile devices). The maximum content container is locked to `1280px` for standard dashboard workspaces, while the live document generation canvas conforms to standardized A4 proportions (`794px` canvas bounds at 96 DPI preview).

- **Mobile Viewport Optimization**: Outermost canvas margin defaults to `1rem` (16px) with an automatic `44px` minimum vertical hit boundary on every clickable target, ensuring swift one-handed thumbs-only review of logbook cards.
- **Rhythm**: Vertical stack layout spacing follows strict multiples of `4px` and `8px`. Component internal padding employs `space-sm` (12px) for compact cards and `space-lg` (24px) for elevated workspace panels.
- **Studio Workspace Split**: Desktop editor modes employ a side-by-side pane architecture (360px collapsible institutional navigation outline, fluid center editor, and 320px contextual inspection/source inspector drawer).

## Elevation & Depth

Depth is established through crisp, low-contrast boundary framing augmented by light ambient shadows, rejecting heavy skeuomorphism and excessive blur layers that cause rendering lag on budget mobile devices.

- **Level 0 (Flat Ground)**: Used by `#F7F8FA` page backdrop.
- **Level 1 (Card & Content Blocks)**: Surface color `#FFFFFF` with a 1px solid border in `#E6E8EC` and a subtle ambient shadow: `box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)`. This is the standard state for weekly logbook entries and dashboard analytics tiles.
- **Level 2 (Interactive Floating Modules & Dropdowns)**: Surface `#FFFFFF`, border `#E6E8EC`, `box-shadow: 0 4px 12px -2px rgba(0, 0, 0, 0.08), 0 2px 6px -1px rgba(0, 0, 0, 0.04)`.
- **Level 3 (Modal Sheets & Mobile Action Drawers)**: High priority overlays and institution guideline upload inspectors. `box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)` with a 40% `#242424` backdrop scrim.
- **Focus Rings**: Pure accessibility compliance with high visibility—2px solid `#F36B21` with a 2px offset on all keyboard and accessibility focus states.

## Shapes

The interface implements a dual radius hierarchy (Level 2: Rounded base) that balances modern software aesthetics with crisp academic geometry:

- **8px (`rounded-md` / 0.5rem)**: Applied to all standard interactive components—text input fields, dropdown trigger buttons, primary/secondary action buttons, pagination items, and inline verification controls.
- **12px (`rounded-lg` / 0.75rem)**: Standard corner radius for primary content cards, weekly logbook entry wrappers, modal dialogs, and institution preview panels.
- **4px (`rounded-sm` / 0.25rem)**: Applied to status tags, category pills, extraction confidence badges, and table cell chips.
- **Pill (`rounded-full`)**: Strictly reserved for circular counter badges (e.g., notification counts, step indicators) and avatar initials.

## Components

### Buttons & Interactive Triggers
- **Primary Action**: Solid `#F36B21` background, `#FFFFFF` text, 8px border radius, font `label-lg` (Inter 500, 14px), 44px minimum height. Hover transitions to `#D95A16`. Active state scales subtly (98%). Disabled state uses `#E6E8EC` background and `#8C93A3` text with no pointer events.
- **Secondary / Structure Button**: `#242424` background with `#FFFFFF` text. Used for critical exports (e.g., "Download Approved DOCX").
- **Outline / Secondary Action**: 1px solid border `#E6E8EC`, `#FFFFFF` surface, `#202124` text. On hover, background shifts to `#F7F8FA` with border tinting to `#8C93A3`.
- **Ghost Action**: Transparent background with `#525866` text, padding `space-xs` `space-sm`, with hover background `#F7F8FA`.

### Activity Verification Chips (Logbook Module)
- Tri-state verification pills:
  - **Performed**: `#10B981` text, `#ECFDF5` background, 1px solid `rgba(16, 185, 129, 0.2)`. Icon: Check-circle.
  - **Assisted**: `#F59E0B` text, `#FFFBEB` background, 1px solid `rgba(245, 158, 11, 0.2)`. Icon: User-check.
  - **Observed**: `#3B82F6` text, `#EFF6FF` background, 1px solid `rgba(59, 130, 246, 0.2)`. Icon: Eye.
- Chips have an internal vertical padding of 4px, horizontal padding of 8px, and 4px border radius.

### Input Fields & Selects
- Height 44px (touch-compliant). 1px border `#E6E8EC`, surface `#FFFFFF`, text `#202124`, placeholder `#8C93A3`, border radius 8px.
- Focus: 1px border `#F36B21` accompanied by a 2px outer ring in `rgba(243, 107, 33, 0.15)`.
- Error state: 1px border `#EF4444` with error helper text displayed directly below the container in 12px Inter.

### Weekly Logbook Cards
- 12px border radius, `#FFFFFF` surface, 1px border `#E6E8EC`.
- Header bar includes week index (e.g., "Week 4: Site Installation & Rigging"), inclusive calendar dates in `#8C93A3`, and an activity distribution badge (e.g., "5 entries verified").
- Internal item rows separated by hairline dividers (`#F7F8FA`). Each row provides an editable description box, equipment tag list, and the activity type toggle chip.

### Document Editor Canvas
- Centered white sheet with Level 2 elevation on a `#F7F8FA` canvas.
- 1-inch virtual margins with visual guide rulers showing institutional boundaries.
- Academic formatting bar pinned above the canvas: Section jumping (Chapters 1 to 5), regenerator control, citation validator, and live DOCX preview switcher.

### Naira Pricing & Entitlement Cards
- Highlights transaction pricing clearly in NGN (Nigerian Naira) with zero obscured fees.
- Single purchase card features 1px solid `#E6E8EC` border; the recommended Institutional tier displays an active 2px border in `#F36B21` with a top-pinned "Recommended for Final Year" badge.